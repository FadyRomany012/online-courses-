        // color switcher
        var colorSheets = [
        {
            color: "#02b3e4",
            title: "Blue",
            href: "./color/default.css"
        },
        {
            color: "#ffb606",
            title: "Yellow",
            href: "./color/yellow.css"
        },
        {
            color: "#7fc540",
            title: "Green",
            href: "./color/green.css"
        }

    ];

    ColorSwitcher.init(colorSheets);  
      
      
